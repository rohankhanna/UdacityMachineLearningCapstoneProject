# Convolutional Neural Network

## Usage

to start the web app run `python run.py`.
