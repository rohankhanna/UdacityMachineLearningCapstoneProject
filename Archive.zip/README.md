# Convolutional Neural Network trained on handwritten Devanagari script characters


## Usage

First follow the instructions inside the devanagari_character_recognition_notebook/README.md file
Then follow the instructions inside the Convolutional_neural_network_user_facing/README.md file

The report is available as report.pdf in this directory

Thank you.