# Convolutional Neural Network


## Usage

Run `pip install -r requirements.txt` to install dependencies. 

to start the jupyter notebook run `jupyter notebook` in this directory.

This will open a webpage in a browser. Click Cell > Run All

When the entire notebook has finished running, a file named basic_cnn_10_epochs23.h5 will be generated in this directory